create
    definer = Maxboy1993@`%` procedure userBirthday(IN userName varchar(50), OUT resultBirthday mediumtext)
BEGIN
    SELECT birthday INTO resultBirthday FROM user WHERE name = userName;
end;

