create
    definer = Maxboy1993@`%` procedure counter()
BEGIN
    SELECT COUNT(*) FROM user;
    SELECT COUNT(*) FROM film;
end;

