create
    definer = Maxboy1993@`%` procedure userCount(OUT count int)
BEGIN
   SELECT count(*) INTO count FROM User;
END;

